S.No.	FileName								Description
1		Bhaav-Dataset.xlsx						The dataset containing 20304 sentences and their annotations
2		Guidelines for Annotators.docx			These are the guidelines to which annotators referred to before starting the annotations and when in doubt
3		Stories to Sentence Mapping.xlsx		This file contains two things: 
													1. Start and End Row number of the stories present in the file Bhaav-Dataset.xlsx. 
													2. Contains the genre of each story present in the database
4		Examples-Simple Sentences.docx			This file contains some examples of sentences from 5 headline categories which are easy to 
												annotate and form some examples from the dataset
5		Examples-Difficult-sentences.docx		This file contains some examples of sentences from 5 headline categories which are difficult to 
												annotate and form some examples from the dataset